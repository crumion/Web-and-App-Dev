// This folder exports all of the necessary keys and IDs necessary for the project

module.exports = {
  APPLICATION_ID: "OaC0VMsA7qJj7dEBdfPpBlB62iqEk0ldmXy7thBm",
  JAVASCRIPT_KEY: "7oatg3gVRA8va15DbDKPaH1pNfpzJJc4Rhu2aNH4",
  SERVER_URL: "https://parseapi.back4app.com/"
};
